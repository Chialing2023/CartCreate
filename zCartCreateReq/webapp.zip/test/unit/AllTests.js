sap.ui.define([
	"CTL/zcartcreaterequistion/test/unit/controller/AddRequistion.controller"
], function () {
	"use strict";
});